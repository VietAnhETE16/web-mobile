| Yêu cầu | Trọng số nhân | Trọng số chia |     |
| ------- | ------------- | ------------- | --- |
Website:
| - Lưu trữ dữ liệu bằng database |     | 1   | 1   |
| ------------------------------- | --- | --- | --- |
- Có chức năng đăng nhập, đăng xuất của người dùng với username, password
| (phân biệt 2 loại người dùng: admin, user) |     | 1   | 1   |
| ------------------------------------------ | --- | --- | --- |
- Có trang hiển thị nội dung khác nhau theo mã của nội dung (sản phẩm/bài
| viết/... - tuỳ theo website lựa chọn là gì) |     | 1   | 1   |
| ------------------------------------------- | --- | --- | --- |
    + Có form bình luận và đánh giá cho nội dung đang xem với các thông tin tên
| người, email, nội dung bình luận, điểm đánh giá |     | 0.5 | 0.5 |
| ----------------------------------------------- | --- | --- | --- |
|                                                 |     | 0.5 | 0.5 |
    + Các bình luận và đánh giá sau khi gửi sẽ được hiển thị công khai
- Ở trang chủ, sau 1’ từ khi mở trang thì hiện quảng cáo một sản phẩm định
| trước dưới dạng popup |     | 1   | 1   |
| --------------------- | --- | --- | --- |
    + Khi người dùng ấn nút đóng popup, thì lần sau mở trang sẽ không hiện lại
| popup này nữa (sử dụng cookie)                         |     | 0.5 | 0.5 |
| ------------------------------------------------------ | --- | --- | --- |
| - Trang giới thiệu và thông tin liên hệ:               |     | 0.5 | 0.5 |
|     + Form gửi ý kiến liên hệ                          |     | 0.5 | 0.5 |
| - Trang quản trị:                                      |     | 1   | 1   |
|     + Hiển thị số lượng view của toàn bộ Website       |     | 0.5 | 0   |
|     + Cho phép cập nhật thông tin ở các trang nội dung |     | 0.5 | 0   |
    + Cho phép hiện danh sách, xoá bình luận của người dùng 0.5 0
- Giao diện responsive cho phép tuỳ chỉnh layout với 3 ngưỡng phân biệt bởi
| các giá trị 800px, 1200px                   |     | 1   | 1   |
| ------------------------------------------- | --- | --- | --- |
| - Thiết kế và trình bày giao diện           |     | 1   | 0   |
| - Tổ chức project                           |     | 1   | 0   |
| - Copy hoặc dùng các thư viện sẵn (penalty) |     | -10 | 0   |
Mobile app:
| - Giao tiếp với website bằng API |     | 2   | 2   |
| -------------------------------- | --- | --- | --- |
| - Màn hình chính                 |     | 1   | 1   |
| - Màn hình đăng nhập             |     |     | 1   |
1
| - Màn hình hiển thị nội dung                           |     | 0.5 | 0.5 |
| ------------------------------------------------------ | --- | --- | --- |
|     + Cho phép người dùng bình luận, đánh giá nội dung |     | 0.5 | 0   |
| - Màn hình ý kiến và liên hệ                           |     | 1   | 1   |
| - Thiết kế và trình bày giao diện                      |     | 1   | 0   |
| - Tổ chức project                                      |     | 1   | 0   |
| - Copy hoặc dùng các thư viện sẵn (penalty)            |     | -10 | 0   |
Điểm tổng